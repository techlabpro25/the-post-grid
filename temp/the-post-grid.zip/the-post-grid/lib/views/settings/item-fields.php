<?php

echo rtTPG()->rtFieldGenerator( rtTPG()->itemFields() );