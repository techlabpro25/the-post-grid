<?php

namespace RT\RadiusBlocks\Helpers;
defined('ABSPATH') || exit;

class Installer
{

    public static function activate() {

    }

    public static function deactivate() {

    }

}